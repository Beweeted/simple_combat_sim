__author__ = 'Steve'


class Unit:
    def __init__(self, n, ch, mh, a, d, atks, arp, rng, pic):
        self.name = n
        self.curr_health = ch
        self.max_health = mh
        self.armour = a
        self.damage = d
        self.attack_speed = atks
        self.armour_piercing = arp
        self.ranged = rng
        self.picture = pic

    def wound(self, d=10, arp=False):
        if not arp:
            d -= self.armour
        self.curr_health -= d
