#  General functionality
import time
import copy

#  GUI libraries
import tkinter as tk
import tkinter.messagebox as mb

#  Background Classes
from Unit import Unit
from TextDisplay import TextDisplay
from Combat import Combat


class TextMenu:
    def __init__(self, option_list):
        self.option_list = option_list

    def print_menu(self):
        print("Your choices are: ")
        pos = 1
        for a in self.option_list:
            print(pos, ": ", a.name, sep='')
            pos += 1

    def prompt_unit(self, question):
        choice = input(question)
        match = False
        while not match:
            try:
                choice = int(choice)
            except ValueError:
                pass
            position = 1
            for o in self.option_list:
                if choice == o.name or choice == position:
                    unit = copy.deepcopy(self.option_list[position-1])
                    match = True
                    break  # Once match is found, quit loop
                position += 1
            if not match:  # If no match found
                choice = input("Invalid input. Please try again: ")
        return unit  # Can't escape while loop without assignment


def old_main():
    #  Initialize the template troops
    serf_template = Unit("Serf", 322, 322, 0, 56, 1, False, False)
    archer_template = Unit("Archer", 156, 156, 0, 97, 1, False, True)
    knight_template = Unit("Knight", 360, 360, 29, 136, 1, False, False)
    sentry_template = Unit("Sentry", 225, 225, 16, 152, 1, True, False)
    soldier_template = Unit("Soldier", 299, 299, 26, 79, 1, False, False)

    army_choices = [
        serf_template,
        archer_template,
        knight_template,
        sentry_template,
        soldier_template,
    ]

    #  Display the menu
    menu = TextMenu(army_choices)
    text_display = TextDisplay
    menu.print_menu()

    #  Request the units to battle
    first_unit = menu.prompt_unit("What unit shall Garret be? ")
    first_unit.name = "Garret - " + first_unit.name
    print(first_unit.name)
    text_display.print_full_unit(first_unit)

    second_unit = menu.prompt_unit("What unit shall Elsa be? ")
    second_unit.name = "Elsa - " + second_unit.name
    text_display.print_full_unit(second_unit)

    #  fite IRL
    combat = Combat(first_unit, second_unit)
    print()
    if first_unit.ranged or second_unit.ranged:
        print("First strike!")
        combat.ranged_attack()
        text_display.print_combat_status(combat)

    while not combat.is_complete():
        combat.do_round()
        time.sleep(1.5)  # makes it look like there are complex calculations
        text_display.print_combat_status(combat)
    text_display.print_combat_winner(combat)


def main():
    pass


class Application(tk.Frame):
    def __init__(self, master=None):
        super().__init__(master)
        self.pack()
        self.initialize_units()
        self.create_widgets()

    def initialize_units(self):
            #  Initialize the template troops
        self.serf_template = Unit("Serf", 322, 322, 0, 56, 1, False, False, tk.PhotoImage(file="unit_images/serf.png"))
        self.archer_template = Unit("Archer", 156, 156, 0, 97, 1, False, True, tk.PhotoImage(file="unit_images/archer.png"))
        self.knight_template = Unit("Knight", 360, 360, 29, 136, 1, False, False, tk.PhotoImage(file="unit_images/knight.png"))
        self.sentry_template = Unit("Sentry", 225, 225, 16, 152, 1, True, False, tk.PhotoImage(file="unit_images/sentry.png"))
        self.soldier_template = Unit("Soldier", 299, 299, 26, 79, 1, False, False, tk.PhotoImage(file="unit_images/soldier.png"))

        self.army_choices = [
            self.serf_template,
            self.archer_template,
            self.knight_template,
            self.sentry_template,
            self.soldier_template,
        ]

    def create_widgets(self):
        self.display = tk.Label(self)
        self.display.pack(side="right")

        self.unit_buttons = [ tk.Button(self, image=u.picture, command=lambda u=u: self.update_picture(u.picture))
                                        for u in self.army_choices]
        for b in self.unit_buttons:
            b.pack(side="top")

        self.quit = tk.Button(self, text="QUIT", fg="red", command=root.destroy)
        self.quit.pack(side="right")

    def update_picture(self, pic):
        self.display.configure(image=pic)
        #mb.showinfo("window title says moo", "hi there, everyone!")


root = tk.Tk()
app = Application(master=root)
app.mainloop()

#  if __name__ == "__main__":
    #  old_main()
